from setuptools import setup

setup (
  name='vsearch',
  version='1.0',
  description='Algunas Search Tools',
  author='Nicasio Sirvent Ruiz',
  autor_email='nicasio.sirvent@gmail.com',
  url='nicasio.sirvent.com',
  py_modules=['vsearch'],
)
